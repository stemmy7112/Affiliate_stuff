
document.addEventListener('DOMContentLoaded', function() {
    const form = document.getElementById('subscribe-form');
    const emailInput = document.getElementById('email');
    const successMessage = document.getElementById('success-message');

    form.addEventListener('submit', function(event) {
        event.preventDefault();
        const email = emailInput.value;
        if (validateEmail(email)) {
            simulateFormSubmission(email).then(() => {
                emailInput.value = '';
                successMessage.classList.remove('hidden');
                setTimeout(() => {
                    successMessage.classList.add('hidden');
                }, 5000);
            }).catch(error => {
                console.error('Error submitting form:', error);
            });
        } else {
            alert('Please enter a valid email address.');
        }
    });

    function validateEmail(email) {
        const re = /^[\w-\.]+@([\w-]+\.)+[\w-]{2,4}$/;
        return re.test(String(email).toLowerCase());
    }

    function simulateFormSubmission(email) {
        return new Promise((resolve) => {
            console.log('Submitting email:', email);
            setTimeout(resolve, 1000);
        });
    }
});
