# Make Me Money

## Description

A platform to help users find tailored investment opportunities based on their preferences and risk appetite.