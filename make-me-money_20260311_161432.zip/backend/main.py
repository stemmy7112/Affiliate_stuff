from fastapi import FastAPI

app = FastAPI()

@app.get("/")
async def health_check():
    return {"status": "running"}

@app.post("/api/investment-opportunities/")
async def get_investment_opportunities(user_preferences: dict):
    # Mock: Example response based on user preferences.
    return [{"title": "Tech Stock A", "potential_return": "8%", "risk": "Medium"},
            {"title": "Real Estate Fund B", "potential_return": "5%", "risk": "Low"}]