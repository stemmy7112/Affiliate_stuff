import React from 'react';
import './style.css';

function App() {
  return (
    <div className="app-container">
      <h1>Make Me Money</h1>
      <p>Discover personalized investment opportunities!</p>
      {/* Components like form for preferences and display opportunities can be added here */}
    </div>
  );
}

export default App;